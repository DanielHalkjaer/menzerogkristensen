=== One.com Performance Cache Plugin ===
Contributors: onecom
Link: https://www.one.com/
Requires at least: 4.3
Tested up to: 4.9
License: GPL v2 or later

== Description ==
With One.com Performance Cache your website loads a lot faster. We save a cached copy of your website on a Varnish server, that will then be served to your next visitors.

== Changelog ==
= v0.1.12
* Fixed PHP warning on PHP v7.3

= v0.1.11
* Fixed the guide link for Swedish locale.

= v0.1.10
* Cookie name fixed

= v0.1.9
* Compatibility information updated

= v0.1.8
* Minor css fixes

= v0.1.7
* Renamed the plugin

= v0.1.6
* Renamed log handles

= v0.1.5
* Minor fixes

= v0.1.4
* Help-desk urls are not working for different languages from WP dashboard
* Minor fixes

= v0.1.3
* Permalink specific messages
* Missing translations
* Minor fixes

= v0.1.2
* Console error on non WP packages

= v0.1.1
* Truncate long purge messages
* Other minor fixes

= v0.1.0
* Initial release.